-- Create `events` table
CREATE TABLE `events` (
  `event_id` int(100) NOT NULL,
  `event_title` text NOT NULL,
  `event_price` int(20) NOT NULL,
  `participents` int(100) NOT NULL,
  `img_link` text NOT NULL,
  `type_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Insert data into `events` with only cs01.jpg and cs02.jpg
INSERT INTO `events` (`event_id`, `event_title`, `event_price`, `participents`, `img_link`, `type_id`) VALUES
(1, 'Photography Workshop', 100, 30, 'cs01.jpg', 1),
(2, 'Music Concert', 200, 100, 'cs02.jpg', 2),
(3, 'Cooking Masterclass', 150, 20, 'cs01.jpg', 3),
(4, 'Dance Competition', 80, 50, 'cs02.jpg', 2),
(5, 'Art Exhibition', 50, 200, 'cs01.jpg', 4),
(6, 'Fitness Workshop', 120, 25, 'cs02.jpg', 3),
(7, 'Business Networking', 250, 50, 'cs01.jpg', 5),
(8, 'Food Festival', 100, 500, 'cs02.jpg', 4);

-- Create `event_type` table
CREATE TABLE `event_type` (
  `type_id` int(10) NOT NULL,
  `type_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Insert data into `event_type` with public event categories
INSERT INTO `event_type` (`type_id`, `type_title`) VALUES
(1, 'Workshops & Learning'),
(2, 'Entertainment'),
(3, 'Lifestyle'),
(4, 'Cultural & Festival'),
(5, 'Professional & Networking');

-- Create `participants` table
CREATE TABLE `participants` (
  `p_id` INT AUTO_INCREMENT PRIMARY KEY,
  `event_id` INT NOT NULL,
  `fullname` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `mobile` VARCHAR(10) NOT NULL,
  `utr_number` VARCHAR(255),
  `event` VARCHAR(255),
  `event_type` VARCHAR(255)
);

-- Insert sample data into `participants`
INSERT INTO `participants` (`p_id`, `event_id`, `fullname`, `email`, `mobile`, `utr_number`, `event`, `event_type`) VALUES
(1, 1, 'John Doe', 'john.doe@example.com', '1234567890', 'UTR123456', 'Photography Workshop', 'Workshops & Learning'),
(2, 2, 'Alice Smith', 'alice.smith@example.com', '9876543210', 'UTR987654', 'Music Concert', 'Entertainment');

-- Add primary keys
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);
ALTER TABLE `event_type`
  ADD PRIMARY KEY (`type_id`);
ALTER TABLE `participants`
  ADD PRIMARY KEY (`p_id`);

-- Add foreign key from `events` to `event_type`
ALTER TABLE `events`
  ADD CONSTRAINT `fk_events_type` FOREIGN KEY (`type_id`) REFERENCES `event_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- Add foreign key from `participants` to `events`
ALTER TABLE `participants`
  ADD CONSTRAINT `fk_participants_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- Add indexes
CREATE INDEX `idx_events_type_id` ON `events` (`type_id`);
CREATE INDEX `idx_participants_event_id` ON `participants` (`event_id`);
CREATE INDEX `idx_participants_email` ON `participants` (`email`);
CREATE INDEX `idx_participants_mobile` ON `participants` (`mobile`);

-- Update AUTO_INCREMENT values
ALTER TABLE `events`
  MODIFY `event_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
ALTER TABLE `event_type`
  MODIFY `type_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
ALTER TABLE `participants`
  MODIFY `p_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
