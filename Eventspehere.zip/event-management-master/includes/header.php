<!DOCTYPE html>
<html lang="en">
  <head>
    <title>EventSphere - Where Moments Become Memories</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Rest of the head content -->
</html>

<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar" style="background: transparent !important;">
    <div class="container">
        <a class="navbar-brand" href="index.php" style="color: #1a365d;">Event<span style="color: #2c5282;">Sphere</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active"><a href="index.php" class="nav-link" style="color: #2d4a6d;">Home</a></li>
                <li class="nav-item"><a href="#events-section" class="nav-link scroll-link" style="color: #2d4a6d;">Events</a></li>
                
                <li class="nav-item cta"><a href="registration.php?event_id=1" class="nav-link" style="background: #1a365d; color: white; border-radius: 20px; padding: 8px 20px;"><span>Register</span></a></li>
            </ul>
        </div>
    </div>
</nav>

<style>
    .navbar {
        background: transparent !important;
    }

    .nav-link:hover {
        color: #1a365d !important;
        font-weight: 600;
    }

    .navbar-brand {
        font-weight: bold;
        font-size: 1.8rem;
    }

    .navbar.scrolled {
        background: rgba(255, 255, 255, 0.95) !important;
    }

    .cta .nav-link:hover {
        background: #2c5282 !important;
        color: white !important;
    }

    .navbar-toggler {
        border-color: #2d4a6d;
    }

    html {
        scroll-behavior: smooth;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scrolling to all links with class 'scroll-link'
    document.querySelectorAll('.scroll-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const headerOffset = 100; // Adjust this value based on your header height
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
});
</script>